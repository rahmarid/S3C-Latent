modifyPop <- function(modelPopulation, idxfail, idxgood) {

  #get the good models
  goodModels <- modelPopulation[idxgood,]

  #include to population
  modelPopulation <- rbind(modelPopulation, goodModels, deparse.level = 0)

  #remove those that failed
  modelPopulation <- modelPopulation[-idxfail,]

  #combined
  #modelPopulation <- rbind(modelPopulation, goodModels, deparse.level = 0)

  return(modelPopulation)
}
