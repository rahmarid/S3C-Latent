
optimalModels <- function(theData, nSubset, allIteration, allPop,
                          allMutRate, allCrossRate, longitudinal,
                          numTime, seed, co, consMatrix, mixture,
                          log, impute, latentList, multiple, nChunk, complementary,
                          hetero) {


  if (!impute) {
    if (longitudinal){
      #get the number of instances of one time slice
      numInstances <- nrow(theData) / (numTime - 1)

      #compute the size of Subset
      sizeSubset <- floor(numInstances / 2) * (numTime - 1)

      #compute sizeSubsetGetData, how many instances drawn from each time slice
      sizeSubsetGetData <- floor(numInstances / 2)

      #compute the number of variables,
      #asummed data already in reshaped network t_0..t_i
      numVar <- ncol(theData) / 2

      #compute the size of the a longitudinal model string
      stringSize <- (numVar * numVar + (numVar * (numVar - 1))) #inter + intra

    } else {
      #for variable sizeSubset
      sizeSubset <- floor(nrow(theData) / 2) #nrow(theData) #BOOTSTRAP

      #for variable numVar, the number of variables in the data
      numVar <- length(latentList) #ncol(theData)

      #the size of a model string
      stringSize <- (numVar * (numVar - 1))
    }
  } else {
    #if impute, still only apply for cross-sectional, not yet longitudinal
    #for variable sizeSubset
    sizeSubset <-floor(nrow(theData[[1]]) / 2)

    #for variable numVar, the number of variables in the data
    numVar <- length(latentList)

    #the size of a model string
    stringSize <- (numVar * (numVar - 1))
  }



  #form constraint
  if (is.null(consMatrix)) {
    consObs <- 0
    consMatrix <- matrix(0, 1, 2, byrow = TRUE)
  } else {
    consObs <- convertCons(consMatrix, numVar)
  }

  #to form a set of "constraints" if there was
  #a factor/latentList with only two indicators

  consLatent <- NULL

  #first check if any latentList with two indicators
  if (any(lengths(latentList) == 2)) {


    #get which latents (indirectly get the number of those latent as well)
    twoIndLatent <- which(lengths(latentList) == 2)
    consLatent <- convertConsLatent(twoIndLatent, numVar)

    #remove those that match the constraint of observed variables
    consLatent <- lapply(consLatent,
                             function(x,y) x[!is.element(x, y)], y=consObs)

  }


  if (multiple) {
    chunk <- toChunk(1:nSubset, nChunk)
  }

  if (complementary) {
    allData <- complData <- list()
    draw <- floor(nSubset / 2)

    for (i in 1:draw) {

      allData[[i]] <- getDataCross(theData, nrow(theData))

      #divide into two complementary subsets
      j <- i + (i - 1)

      complData[[j]] <- allData[[i]][1:sizeSubset, ]
      complData[[j + 1]] <- allData[[i]][(sizeSubset + 1):nrow(theData), ]
    }
  }



  #l <- NULL
  #allModel <- allScore <- NULL
  # the main loop / outer loop -----------------------------------------
 masterList <- foreach(l = 1:nSubset, .inorder = FALSE,
                       .packages = c('stablespecImptLatent', 'mvtnorm', 'sfsmisc')) %dopar% {


    tryCatch({

    allModel <- allScore <- NULL

    #set seed
    set.seed(seed[l])


    if (!is.null(log)) {
      sink(log, append=TRUE)
      cat(paste(Sys.time(), ": Starting subset ", l, "\n", sep = ''))
    }


    if (multiple) {

      for (i in 1:nChunk) {
        if (l %in% chunk[[i]]) {
          iteration <- allIteration[i]
          mutRate <- allMutRate[i]
          crossRate <- allCrossRate[i]
          nPop <- allPop[i]
        }
      }

    } else {

      iteration <- allIteration
      mutRate <- allMutRate
      crossRate <- allCrossRate
      nPop <- allPop

    }

    #if not impute
    if(!impute) {
      #draw a subset from the data
      if (longitudinal) {

        newData <- getDataLongi(theData, numTime, sizeSubsetGetData)

      } else { #if cross-sectional data

        if (complementary) {
          newData <- complData[[l]]
        } else {
          newData <- getDataCross(theData, sizeSubset)
          #newData <- theData #bootstrap
        }

      }
    } else {
      #if impute
      #imputedData <- theData[[l]]

      # newData <- as.data.frame(imputedData[sample(1:nrow(imputedData),
      #                                             sizeSubset, replace=FALSE),])
      newData <- getDataCross(theData[[l]], sizeSubset)

    }


    #make an initial population
    #initialModels <- initialPopulation(numVar, stringSize,
                                      # longitudinal, consMatrix)
   # initialModels <- rbind(initialModels,
    #                       genPopulation(nPop-nrow(initialModels), numVar,
    #                                     longitudinal, consObs, theLatent))
    initialModels <- genPopulation(nPop, numVar,
                                   longitudinal, consObs, consLatent)



    #perform initial computation
    #if model causal relations among observed and latent variables

      initialResult <- gatherFitness(newData, initialModels, sizeSubset,
                                     numVar, l, longitudinal, co,
                                     mixture, latentList,
                                     allModel, allScore, crossRate, hetero)




   # modify initialModels
    if (initialResult$diff > 0) {
      #if there is failed models

      initialModels <- modifyPop(initialModels,
                                 initialResult$indexFail,
                                 initialResult$indexGood)

    }

      # FIRST GENERATION----------------------------------------------------

      # sorted first generation, here is P0
      #preP0 <- fastNonDominatedSort(initialResult)
       preP0 <- fastNonDominatedSort(initialResult$result)


      #to get the matrix of indices from Front1..n
      indexP0 <- convertFront(preP0)
      P0 <- initialModels[indexP0, ]

      # initial Selection
      currentPop <- P0

      # to get the first front's fitness
      front1Fitness <- initialResult$result[preP0[[1]], ]

      #to get the first front's models
      front1Model <- initialModels[preP0[[1]], ]

      #to get database of allscore
      allModel <- initialModels
      allScore <- initialResult$result

      # the loop of NSGA --------------------------------------------
      for (j in 1:iteration) {

        # Crossover
        i <- 1
        while (i < nPop) {
          toss <- runif(1, 0, 1)
          if (toss <= crossRate) {
            #generate crossovered offspring, by taking two consecutive models
            offsprings <- crossOver(currentPop[i, ],
                                    currentPop[i+1, ], numVar,
                                    longitudinal, consLatent)
            currentPop[i, ] <- offsprings[[1]]
            currentPop[i+1, ] <- offsprings[[2]]
          }
          #to take the next two consecutive models
          i <- i + 2
        }

        # MUTATION -----------------------------
        for (i in 1:nPop) {
          currentPop[i,] <- mutation(currentPop[i, ], mutRate,
                                     numVar, consObs, longitudinal, consLatent)
        }

        allR0 <- rbind(P0, currentPop)
        preR0 <- gatherFitness(newData, allR0, sizeSubset, numVar,
                               l, longitudinal, co, mixture, latentList,
                               allModel, allScore, crossRate, hetero)


        if (preR0$diff > 0) {
          #if there is failed model

          allR0 <- modifyPop(allR0,
                             preR0$indexFail,
                             preR0$indexGood)

        }

        allModel <- rbind(allModel, allR0)
        allScore <- rbind(allScore, preR0$result)



        ranking <- fastNonDominatedSort(preR0$result)
        rnkIndex <- integer(nPop)

        i <- 1
        while (i <= length(ranking)) {
          rnkIndex[ranking[[i]]] <- i
          i <- i + 1
        }

        #to get the range of each objective
        objRange <- apply(preR0$result[, 1:2], 2, max) - apply(preR0$result[, 1:2], 2, min)

        #to assign the crowded distance for each member in each front
        assignedDist <- crowdingDistance(preR0$result, ranking, objRange)

        #to sort the members in each front in R0 based on the crowded distance
        sortedDist <- sortBasedOnDist(ranking, assignedDist)

        #order and get R0
        indexR0 <- convertFront(sortedDist)
        R0 <- allR0[indexR0, ]

        #new P0
        P0 <- R0[1:nPop, ]

        # if the length of the first front < nPop, take them all
        # or take them as many as nPop otherwise (if length is more than nPop)
        if (length(sortedDist[[1]]) < nPop) {
          lengthInd <- length(sortedDist[[1]])
          takenInd <- sortedDist[[1]]
        } else {
          lengthInd <- nPop
          takenInd <- sortedDist[[1]][1:nPop]
        }

        front1Fitness <- rbind(front1Fitness, preR0$result[takenInd, ])

        #to get the first front models
        front1Model <- rbind(front1Model, allR0[takenInd, ])

        # New currentPop
        currentPop <- cbind(P0, rnkIndex[indexR0[1:nPop, ]],
                            assignedDist[indexR0[1:nPop, ], ])
        currentPop <- nsga2R::tournamentSelection(currentPop, nPop, 2)
        currentPop <- currentPop[, 1:stringSize]
      }

      toFrontOneIndex <- fastNonDominatedSort(front1Fitness)

      #to get the model of 1st front of all FrontOne
      firstFront1Model <- front1Model[toFrontOneIndex[[1]], ]

      #to get the fitness of 1st front of FrontOne
      firstFront1Fitness <- front1Fitness[toFrontOneIndex[[1]], ]

      firstFront1Merged <- cbind(firstFront1Model, firstFront1Fitness)

      uniqueFirstFront <- unique(firstFront1Merged)

      if (!is.null(log)) {
        sink(log, append=TRUE)
        cat(paste(Sys.time(), ": Finished subset ", l, "\n", sep = ""))
      }


      uniqueFirstFront

       }, error = function(e) {

        return(paste("Error di subset ke ",l))
       })
  }

  return(list(listOfFronts=masterList, num_var=numVar,
              string_size=stringSize, cons_matrix = consMatrix))
}
