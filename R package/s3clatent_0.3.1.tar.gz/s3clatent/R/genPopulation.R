genPopulation <- function(nPop, numVar, longitudinal, consVector, consLatent) {

  modelPopulation <- NULL


  for (i in 1:nPop) {

    # generate random string for intra-slice
    #intraString <- round(runif(numVar * (numVar - 1)))

    dag <- pcalg::randDAG(n = numVar,
                          d = sample(x = 0.6:(numVar-1), size = 1), #rule of thumb
                          #d = 2, #poorest so far, yet used commonly?
                          #d = sample(x = 0:(numVar-1), size = 1), #seems better when numVar increases
                          method = "er")
    dag <- as(dag, "matrix")
    dag[dag > 0] <- 1
    diag(dag) <- NA
    intraString <- as.vector(dag[!is.na(dag)])

    #if there is a latent(s) with two indicators
    if (!is.null(consLatent)) {

      latentIdx <- NULL

      for (j in 1:length(consLatent)) {

        #if all latent indices are 0
        if (all(intraString[consLatent[[j]]] == 0)) {
          latentIdx <- c(latentIdx, sample(consLatent[[j]], 1))
        }
      }

      if (!is.null(latentIdx)) {
        #impose one of the latent indices (for each latent) to be nonzero
        intraString[unique(latentIdx)] <- 1

      }
    }

    #Note that we don't need to double check whether the repaired model, if so,
    #will cancel the impose of latent indices.
    #This is because, the impose is applied iff all indices appear to be zero.
    #In that case, impose will lead to the two-indicator latent having one
    #connection (could be a cause or effect). In the case not all indices are zero,
    #that means the latent has no relation(s) and therefore latentIdx. And if the relation(s) is
    #cyclic, the repair function will fix it. Recall that to be a cyclic, a node must have
    #degree 2 (relations). So one deletion won't make the two-indicator latent become independent.

      #get all indices as a vector, and remove redundant index(s)
      #consLatent <- unique(sapply(consLatentList, function(x) sample(x, 1)))



    # satisfy the constraint of observed variables
    if (any(intraString[consVector] != 0)) {
      intraString[consVector] <- 0
    }


    if (longitudinal) {
      #generate random string for inter-slice
      interString <- round(runif(numVar * numVar))
      stringModel <- c(interString, intraString)

      #check whether this new string model is cyclic
      tmpModel <- stringToMatrix1(stringModel, numVar, longitudinal)
      if (!ggm::isAcyclic(tmpModel)) {
        stringModel <- repairCyclicModel(stringModel, numVar, longitudinal)
      }

      #stringModel <- repairCyclicModel(stringModel, numVar, longitudinal)
      theModel <- matrix(stringModel, 1,
                         (numVar * (numVar - 1)) + (numVar * numVar))
      #the length of the string is intra + inter-slice
    } else {

      #if cross-sectional
      #stringModel <- intraString

      #check whether this NEW MANIPULATED string model is cyclic
      tmpModel <- stringToMatrix1(intraString, numVar, longitudinal)
     if (!ggm::isAcyclic(tmpModel)) {
        intraString <- repairCyclicModel(intraString, numVar, longitudinal)
       #stringModel <- repairCyclicModel(stringModel, numVar, longitudinal)
     }

     #theModel <- matrix(stringModel, 1, numVar * (numVar - 1))
     theModel <- matrix(intraString, 1, numVar * (numVar - 1))
    }
    modelPopulation <- rbind(modelPopulation, theModel)
  }
  return(modelPopulation)
}
