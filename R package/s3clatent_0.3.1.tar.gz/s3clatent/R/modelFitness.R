gatherFitness <- function(dataSet, allModelString, sizeSubset,
                         numVar, index, longitudinal, co, mixture,
                         latentList, allModel, allScore, label, hetero) {

  #result <- matrix(0, nrow(allModelString), 4)
  result <- idxfail <- idxgood <- NULL

  if (longitudinal) {
    for (i in 1:nrow(allModelString)) {

      theModel <- longiMatrixFill(allModelString[i, ], numVar)
      #convert model into string of characters to be read by sem::specifyEquations
      modelChar <- writeModel(theModel, numVar, longitudinal)
      result <- rbind(result, getFitness(dataSet, modelChar, sizeSubset,
                                         index, co, mixture))
    }

  } else {
    #if cross-sectional

    if (!is.null(allModel)) {

      for (i in 1:nrow(allModelString)) {

        a <- which(apply(allModel, 1, toCheck, z = allModelString[i, ]))

        if (length(a) > 0) {

          result <- rbind(result, allScore[a[1], ])

        } else {

          theModel <- stringToMatrix1(allModelString[i, ], numVar, longitudinal)
          #convert model into string of characters to be read by sem::specifyEquations
          if (hetero) {
            modelChar <- writeModel2(theModel, numVar, longitudinal, latentList)
          } else {
            modelChar <- writeModel(theModel, numVar, longitudinal, latentList)
          }


          #result <- rbind(result, getFitness(dataSet, modelChar, sizeSubset,
          # index, co, mixture))
          thisResult <- getFitness(dataSet, modelChar,
                                   sizeSubset, index, co, mixture, label)


          if (!is.null(thisResult) && thisResult[1] >= 0) {

            result <- rbind(result, thisResult, deparse.level = 0)

          } else {

            result <- rbind(result, rep(NA, 5))
            #get the index of the failed model(s)
            idxfail <- c(idxfail, i)

          }
        }
      }

    } else {

      for (i in 1:nrow(allModelString)) {

        theModel <- stringToMatrix1(allModelString[i, ], numVar, longitudinal)
        #convert model into string of characters to be read by sem::specifyEquations
        if (hetero) {
          modelChar <- writeModel2(theModel, numVar, longitudinal, latentList)
        } else {
          modelChar <- writeModel(theModel, numVar, longitudinal, latentList)
        }

        #result <- rbind(result, getFitness(dataSet, modelChar, sizeSubset,
               # index, co, mixture))
        thisResult <- getFitness(dataSet, modelChar, sizeSubset,
                                 index, co, mixture, label)

        if (!is.null(thisResult) && thisResult[1] >= 0) {

          result <- rbind(result, thisResult, deparse.level = 0)

         } else {

          result <- rbind(result, rep(NA, 5))
          #get the index of the failed model(s)
          idxfail <- c(idxfail, i)
        }
      }
    }
  }



    #if (nrow(result) < nrow(allModelString)) {
     if (length(idxfail) > 0) {

      theDifference <- length(idxfail)
      good <- 1:nrow(allModelString)
      good <- good[-idxfail]

      if (theDifference > length(good)) {
        idxgood <- sample(x = good, size = theDifference, replace = TRUE)
      } else {
        idxgood <- sample(x = good, size = theDifference, replace = FALSE)
      }


      # include those randomly selected from good models
      result <- rbind(result, result[idxgood, ])

      #remove failed scores / NA
      result <- na.omit(result)

     } else {
      theDifference <- 0}
  #}


  #result <- cbind(result, replicate(nrow(result), theDifference))
  result <- list(result=result, diff=theDifference,
                 indexFail=idxfail, indexGood=idxgood)

  return(result)
}






getFitness <- function(dataSet, modelChar, sizeSubset,
                       index, co, mixture, label) {

  score <- tryCatch({
  # write the model into variable model_spec
  model_spec <- suppressMessages(sem::specifyEquations(text = modelChar))

  if(mixture) {

    #get the index of factor variables
    idx <- NULL
    for (i in 1:ncol(dataSet)) {
      if(is.factor(dataSet[,i])) {
        idx <- c(idx, i)
      }
    }

  #e <- 0.1
    #corData <- polycor::hetcor(dataSet, std.err = FALSE)$correlations
    corData <- lavaan::lavCor(dataSet, ordered = names(dataSet)[idx])
    #regularization
    #coData <- (sizeSubset * corData +
                # (e * diag(1, ncol(dataSet)))) / (sizeSubset + e * 1)
    coData <- (sizeSubset * corData + diag(1, ncol(dataSet))) / (sizeSubset + 1)

    #coData <- corData
  } else {

    # if all variable is continous
    if(co == "covariance") {
      #covariance
      coData <- cov(dataSet)
    } else { #correlation
      coData <- cor(dataSet)
    }

  }

  # a variables for new names of the data set
  theNames <- list()
  for(i in 1:ncol(dataSet)) {
    theNames[[i]] <- paste('var', i, sep="")
  }
  rownames(coData) <- colnames(coData) <- c(unlist(theNames))

  #compute the SEM
  theFitness <- sem::sem(model_spec, coData, sizeSubset)
  #get the summary
  #fitSummary <- summary(theFitness)

  #------------------------
  n.fix <- theFitness$n.fix
  t <- theFitness$t
  n <- theFitness$n
  df <- n*(n + 1)/2 - t - n.fix*(n.fix + 1)/2

  #chi <- fitSummary$chisq
  chi <- theFitness$criterion * (sizeSubset - 1) #(N-1)FML

  #df <- fitSummary$df #- 61
  bic <- BIC(theFitness)

  #if (df == 0) {
 #   chi <- bic <- 0
 # }

#return(c(chi, df, bic, index, label)) # yielding the same result as below
c(chi, df, bic, index, label)
}
  , error = function(c) {
    #print(paste("error",j))
    return(NULL)}
  )

return(score)
}




toCheck <- function(x,z) {
  return(all(x == z))
  }


