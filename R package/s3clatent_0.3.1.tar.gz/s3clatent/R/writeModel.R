writeModel <- function(theModel, numVar, longitudinal, latent) {

  #not yet for longitudinal
  if (longitudinal) {
    numVar <- numVar * 2
  }

  indeks <- 0
  forVariance <- modelString <- NULL
  namLatent <- names(latent)


  for (j in 1:numVar) {
    counter <- j
    jExists <- FALSE

    for (k in 1:numVar) {
      if (j != k && counter == j) {
        #rowwise; row by row
        if (theModel[k, j] == 1){
          jExists <- TRUE
          indeks <- indeks + 1
          modelString <- paste(modelString, namLatent[j], ' = par',
                               indeks , '*', namLatent[k], ' ', sep="")
          counter <- counter + 1
        }
      } #if any other cause/independent variable
      else if (j != k && counter != j) {
        if (theModel[k, j] == 1){
          indeks <- indeks + 1
          modelString <- paste(modelString, '+ par', indeks,
                               '*', namLatent[k], ' ', sep="")
        }
      }
    }

    if (jExists) {
      modelString <- paste(modelString, '\n')
    }
    # else {
    #  forVariance <- c(forVariance, j)
    #}
  }


  latentIndicator <- varIndicator <- varLatent <- NULL
  #idx <- idxL <- 0
  idx <- 0


  for (i in 1:length(latent)) {

    #if we want to estimate the variance of latent
    varLatent <- paste(varLatent, 'V(', names(latent)[i], ") = zeta", i,"\n",  sep="")

    for(j in 1:length(latent[[i]])) {


      #for the first latent
      if (j == 1) {
        idx <- idx + 1

        #fix the first indicator loading
        latentIndicator <- paste(latentIndicator, 'var',
                                 latent[[i]][j]," = 1*",
                                 names(latent)[i], "\n", sep="")



        #if only one indicator on the latent
        if (length(latent[[i]]) == 1) {
          #to fix the variance of the indicator
          varIndicator <- paste(varIndicator,
                                'V(var', latent[[i]][j], ') = 0 \n', sep="")

        } else{ #if more than one indicator
          varIndicator <- paste(varIndicator,
                                'V(var', latent[[i]][j], ') = delta', latent[[i]][j], "\n", sep="")
        }

        #for the rest of the latent
      } else {
        # idx <- idx + 1

        latentIndicator <- paste(latentIndicator, 'var',
                                 latent[[i]][j], " = lamda",  latent[[i]][j], "*",
                                 names(latent)[i], "\n", sep="")


        varIndicator <- paste(varIndicator,
                              'V(var', latent[[i]][j], ') = delta', latent[[i]][j], "\n", sep="")

      }
    }
  }

  modelString <- paste(latentIndicator, modelString, varLatent, varIndicator)

  return(modelString)
}















