mutation <- function(modelString, mutRate, numVar, cons, longitudinal, consLatent){

  if (longitudinal) {
    if (!all(cons == 0)) {
      cons <- cons + (numVar * numVar)
    }
  }

  for (i in 1:length(modelString)) {

    toss <- runif(1, 0, 1)
      # if toss <= mutation rate and i is not constraint
      if (toss <= mutRate && all(cons != i)) {
        #modelString[i] <- (modelString[i] - 1)^2
        modelString[i] <- 1 - modelString[i]
      }
  }


  #if any two-indicator latent constraint
  if (!is.null(consLatent)) {

    latentIdx <- NULL

    for (j in 1:length(consLatent)) {

      #if all latent indices are 0
      if (all(modelString[consLatent[[j]]] == 0)) {
        latentIdx <- c(latentIdx, sample(consLatent[[j]], 1))
      }
    }

    if (!is.null(latentIdx)) {

      #impose one of the latent indices (for each latent) to be nonzero
      modelString[unique(latentIdx)] <- 1

    }
  }

  #if the model is cyclic
  if (!ggm::isAcyclic(stringToMatrix1(modelString, numVar, longitudinal))) {

      theModel <- cycleRepair(stringToMatrix1(modelString,
                                              numVar, longitudinal))
      diag(theModel) <- NA
      intra <- as.vector(theModel)

      if(longitudinal) {
        modelString <- c(modelString[1:(numVar * numVar)],
                         intra[!is.na(intra)])
      } else {
        modelString <- intra[!is.na(intra)]
      }

  }
  return(modelString)
}

#modelString <- sapply(modelString, mutate(x, cons), cons=cons)
# mutate <- function(x, cons) {
#   toss <- runif(1, 0, 1)
#   # if toss <= mutation rate and i is not constraint
#   if (toss <= mutRate && all(cons != i)) {
#     x <- (x - 1)^2
#   }
# }
