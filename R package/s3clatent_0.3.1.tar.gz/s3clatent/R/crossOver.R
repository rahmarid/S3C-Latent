crossOver <- function(stringModelA, stringModelB, numVar, longitudinal, consLatent) {
  if (longitudinal) {
    #get intra block from parenta A and B
    #so for longitudinal model, the swap is between intra
    fromA <- stringModelA[(numVar * numVar + 1):length(stringModelA)]
    fromB <- stringModelB[(numVar * numVar + 1):length(stringModelB)]

    #swap to reproduce offsprings
    offSpringA <- c(stringModelA[1:(numVar * numVar)], fromB)
    offSpringB <- c(stringModelB[1:(numVar * numVar)], fromA)

  } else {
    #if cross-sectional data

    # get a half from each parent
    fromA <- stringModelA[1:round(length(stringModelA) / 2)]
    fromB <- stringModelB[1:round(length(stringModelB) / 2)]

    #swap
    offSpringA <- c(fromB, stringModelA[(round(length(stringModelA) /
                                                 2) + 1):length(stringModelA)])
    offSpringB <- c(fromA, stringModelB[(round(length(stringModelB) /
                                                 2) + 1):length(stringModelB)])


    #if any two-indicator latent constraint
    if (!is.null(consLatent)) {

      latentIdxA <-  latentIdxB <- NULL

      for (j in 1:length(consLatent)) {

        #if all latent indices are 0
        if (all(offSpringA[consLatent[[j]]] == 0)) {
          latentIdxA <- c(latentIdxA, sample(consLatent[[j]], 1))
        }

        #if all latent indices are 0
        if (all(offSpringB[consLatent[[j]]] == 0)) {
          latentIdxB <- c(latentIdxB, sample(consLatent[[j]], 1))
        }
      }

      if (!is.null(latentIdxA)) {

        #impose one of the latent indices (for each latent) to be nonzero
        offSpringA[unique(latentIdxA)] <- 1
      }

      if (!is.null(latentIdxB)) {

        #impose one of the latent indices (for each latent) to be nonzero
        offSpringB[unique(latentIdxB)] <- 1
      }
    }

    #check whether the children are cyclic, if so then repair
    if(!ggm::isAcyclic(stringToMatrix1(offSpringA, numVar, longitudinal))){

      theModelA <- cycleRepair(stringToMatrix1(offSpringA, numVar, longitudinal))

      diag(theModelA) <- NA
      intraA <- as.vector(theModelA)
      offSpringA <- intraA[!is.na(intraA)]
    }

    if(!ggm::isAcyclic(stringToMatrix1(offSpringB, numVar, longitudinal))){
      theModelB <- cycleRepair(stringToMatrix1(offSpringB, numVar,
                                               longitudinal))

      diag(theModelB) <- NA
      intraB <- as.vector(theModelB)
      offSpringB <- intraB[!is.na(intraB)]
    }
  }
  return(list(offSpringA, offSpringB))
}
