repairCyclicModel <- function(stringModel = NULL, numVar = NULL,
                              longitudinal = NULL) {

  if (!is.null(stringModel)) {
    if (!(all(stringModel %in% 0:1)) || is.matrix(stringModel)) {
      stop("Argument numVar should be binary vector.")
    }

  } else {
    stop("Argument stringModel cannot be missing.")
  }

  if (!is.null(numVar)) {
    if (!is.numeric(numVar) || is.matrix(numVar)) {
      stop("Argument numVar should be positive numeric, e.g., 6.")
    }
  } else {
    stop("Argument numVar cannot be missing.")
  }

  if (!is.null(longitudinal)) {
    if (!is.logical(longitudinal)) {
      stop("Argument longitudinal should be either logical TRUE or FALSE.")
    }
  } else {
    stop("Argument longitudinal cannot be missing.")
  }

  # convert model string into matrix
  # if longitudinal = TRUE, then only the intraString would be checked
  theModel <- stringToMatrix1(stringModel, numVar, longitudinal)

  # if the model is cyclic
  if(!ggm::isAcyclic(theModel)) { # instead if(ggm::isAcyclic(theModel))

    #repair the model
    theModel <- cycleRepair(theModel)

    #to convert back from matrix to vector
    diag(theModel) <- NA
    stringModel_intra <- as.vector(theModel)

    if (longitudinal) {
      #after being repaired, the intraString is combined
      #again with its interString
      resModel <- c(stringModel[1:(numVar * numVar)],
                    stringModel_intra[!is.na(stringModel_intra)])
    } else { #if cross-sectional
      resModel <- stringModel_intra[!is.na(stringModel_intra)]
    }
    return(resModel)

  } else {
    # if Acyclic
    # both longitudinal and cross-sectional
    return(stringModel)
  }
}

cycleRepair <- function(theModel) {
  for (i in 2:nrow(theModel)) {
    #start from two, as a cyclic must involve at least two nodes

    squaredModel <- matrixcalc::matrix.power(theModel, i)
    cycle <- sum(diag(squaredModel))

    while (cycle != 0) {
    #if (cycle != 0) {
      theIndex <- which(diag(squaredModel) != 0)

      arc <- FALSE
      while(arc == FALSE) {
        kl <- sample(theIndex, 2)
        if(theModel[kl[1],kl[2]] != 0) {
          theModel[kl[1],kl[2]] <- 0
          arc <- TRUE
        }
      }

      #check if we need this two lines below, and the while (cycle!= 0) as well
      squaredModel <- matrixcalc::matrix.power(theModel, i)
      cycle <- sum(diag(squaredModel))
    }
  }
  return(theModel)
}
